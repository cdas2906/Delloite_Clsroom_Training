/*package com.training.spring;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.training.spring.dao.BillDetailsDAO;
import com.training.spring.dao.BillDetailsDAOImpl;
import com.training.spring.model.UserDetails;

public class BillDetailsDAOImplTest {
	BillDetailsDAO billDetailsDAO;
	UserDetails u=new UserDetails("Jai123","Jai","jai123@gmail.com","jai@123");

	@Before
	public void setUp() throws Exception {
		billDetailsDAO=new BillDetailsDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		billDetailsDAO=null;
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testAddUser() {
		
		assertEquals(1,billDetailsDAO.addUser(u));
	}
	
	@Test
	public void testSaveBill() {
		
	}
	
	@Test
	public void testDisplayBill() {
		
	}

}
*/