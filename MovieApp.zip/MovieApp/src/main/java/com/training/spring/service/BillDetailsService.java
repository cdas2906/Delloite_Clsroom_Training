package com.training.spring.service;

import com.training.spring.model.BillDetails;
import com.training.spring.model.UserDetails;

public interface BillDetailsService {

	public void addUser(UserDetails u);
	public boolean validateUser(UserDetails u);
	public BillDetails displayBill(String username);
	public void saveBill(BillDetails b);
	
	
}
