package com.training.spring.dao;





import com.training.spring.model.BillDetails;
import com.training.spring.model.UserDetails;

public interface BillDetailsDAO {

	public void addUser(UserDetails u);
	public boolean validateUser(UserDetails u);
	public void saveBill(BillDetails b);
	public BillDetails displayBill(String username);
	
	
}
