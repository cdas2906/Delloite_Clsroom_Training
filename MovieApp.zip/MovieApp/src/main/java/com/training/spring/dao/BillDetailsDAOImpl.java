package com.training.spring.dao;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;


import com.training.spring.model.BillDetails;
import com.training.spring.model.UserDetails;

@Repository
public class BillDetailsDAOImpl implements BillDetailsDAO {
	
	private static final Logger logger = LoggerFactory.getLogger(BillDetailsDAOImpl.class);

	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	@Override
	public void addUser(UserDetails u) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(u);
	}

	@Override
	public BillDetails displayBill(String username) {
		Session session = this.sessionFactory.getCurrentSession();
		  Criteria criteria=session.createCriteria(BillDetails.class);
	       BillDetails billDetails=(BillDetails) criteria.add(Restrictions.eq("username", username));
	       return billDetails;
	}
	
	@Override
	public void saveBill(BillDetails b) {
		Session session = this.sessionFactory.getCurrentSession();
		session.persist(b);
		
	}
	@Override
	public boolean validateUser(UserDetails u) {
		System.out.println(u);
		Session session = this.sessionFactory.getCurrentSession();
		Criteria criteria=session.createCriteria(UserDetails.class).add(Restrictions.eq("username", u.getUsername()))
				 .add(Restrictions.eq("password", u.getPassword()));
		 List <UserDetails> data=criteria.list();
		 System.out.println(data);
		 if(data.size()!=0)
			 return true;
		 else
			 return false;
		
	}

		
	}

