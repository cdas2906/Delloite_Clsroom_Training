  package com.training.spring;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.training.spring.model.BillDetails;
import com.training.spring.model.UserDetails;
import com.training.spring.service.BillDetailsService;


@Controller
public class BillDetailsController {
	
	private BillDetailsService billDetailsService;
	
	@Autowired(required=true)
	@Qualifier(value="billDetailsService")
	public void setBillDetailsService(BillDetailsService bs){
		this.billDetailsService = bs;
	}
	
	@RequestMapping(value ="/save")
	public String saveBill(Model model,BillDetails billDetails, HttpServletRequest request) {
		HttpSession se = request.getSession();
		String uname=(String) se.getAttribute("uname");
		System.out.println("UNNNNNNNNAMEEE :"+uname);
		billDetails.setUsername(uname);
		int totalAmount = billDetails.getPrice() * billDetails.getTotalSeats();
		billDetails.setBillAmount(totalAmount);
		System.out.println("Bill Amount :    "+totalAmount);
		se.setAttribute("totalBillAmount", totalAmount);
		//code to invoke the service layer to save the bill details in db
		this.billDetailsService.saveBill(billDetails);
		model.addAttribute("recip", new BillDetails());
		return "recip";
	}
	
	@RequestMapping(value= "/signUp", method = RequestMethod.GET)
	public String addUser(@ModelAttribute("userdetails") UserDetails u){
		System.out.println("all the user details :"+ u);
		
		this.billDetailsService.addUser(u);
		System.out.println("Details :"+u);
		return "redirect:/SignUp.html";
	}
	@RequestMapping(value= "/home", method = RequestMethod.POST)
	public String validateUser(UserDetails u,HttpServletRequest request){
		HttpSession session = request.getSession();
		session.setAttribute("uname", u.getUsername());
		boolean result =billDetailsService.validateUser(u);
		System.out.println(result);
			if(result==true)
		{
			return "redirect:/home.html";
		}
		else
		{
			return "redirect:/index.html";
		}

	}
	
/*@RequestMapping(value = "/savebill")
	public String displayBill(Model model,BillDetails billDetails,String username) {
		this.billDetailsService.displayBill(username);
		model.addAttribute("recip", new BillDetails());
		return "recip";
	
		
	}*/
	
}
