package com.training.spring.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="billdetails")
public class BillDetails implements Serializable{
	
	@Id
	@Column
	private String username;
	
	@Column
	private int price;
	
	@Column
	private double billAmount;
	
	@Column
	private String billDate;
	
	@Column
	private int totalSeats;
	

	public BillDetails() {
		super();
	}


	public BillDetails(String username, int price, double billAmount, String billDate, int totalSeats) {
		super();
		this.username = username;
		this.price = price;
		this.billAmount = billAmount;
		this.billDate = billDate;
		this.totalSeats = totalSeats;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public double getBillAmount() {
		return billAmount;
	}


	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}


	public String getBillDate() {
		return billDate;
	}


	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}


	public int getTotalSeats() {
		return totalSeats;
	}


	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}


	@Override
	public String toString() {
		return "BillDetails [username=" + username + ", price=" + price + ", billAmount=" + billAmount + ", billDate="
				+ billDate + ", totalSeats=" + totalSeats + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(billAmount);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((billDate == null) ? 0 : billDate.hashCode());
		result = prime * result + price;
		result = prime * result + totalSeats;
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BillDetails other = (BillDetails) obj;
		if (Double.doubleToLongBits(billAmount) != Double.doubleToLongBits(other.billAmount))
			return false;
		if (billDate == null) {
			if (other.billDate != null)
				return false;
		} else if (!billDate.equals(other.billDate))
			return false;
		if (price != other.price)
			return false;
		if (totalSeats != other.totalSeats)
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}


	
}
