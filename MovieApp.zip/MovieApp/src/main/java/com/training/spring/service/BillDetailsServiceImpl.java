package com.training.spring.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.training.spring.dao.BillDetailsDAO;
import com.training.spring.model.BillDetails;
import com.training.spring.model.UserDetails;

@Service
public class BillDetailsServiceImpl implements BillDetailsService {
	
	@Autowired
	private BillDetailsDAO billDetailsDAO;

	public void setBillDetailsDAO(BillDetailsDAO billDetailsDAO) {
		this.billDetailsDAO = billDetailsDAO;
	}

	@Override
	@Transactional
	public void addUser(UserDetails u) {
		this.billDetailsDAO.addUser(u);
	}

	@Override
	@Transactional
	public BillDetails displayBill(String username) {
		return this.billDetailsDAO.displayBill(username);
	}

	@Override
	@Transactional
	public void saveBill(BillDetails b) {
		this.billDetailsDAO.saveBill(b);
		
	}

	@Override
	@Transactional
	public boolean validateUser(UserDetails u) {
		return this.billDetailsDAO.validateUser(u);
	}



}
